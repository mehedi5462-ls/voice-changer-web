import React, { useState } from "react";
import axios from "axios";

function App() {
  const [text, setText] = useState("");
  const [audioUrl, setAudioUrl] = useState("");

  const generateVoice = async () => {
    const response = await axios.post("http://localhost:5000/generate", { text }, { responseType: "blob" });
    const url = URL.createObjectURL(response.data);
    setAudioUrl(url);
  };

  return (
    <div style={{ padding: 30 }}>
      <h1>🎤 বাংলা ভয়েস চেঞ্জার</h1>
      <textarea value={text} onChange={(e) => setText(e.target.value)} rows="5" cols="60" />
      <br />
      <button onClick={generateVoice}>🎧 Preview</button>
      <br />
      {audioUrl && (
        <>
          <audio controls src={audioUrl} />
          <br />
          <a href={audioUrl} download="output.mp3">⬇️ Download</a>
        </>
      )}
    </div>
  );
}

export default App;