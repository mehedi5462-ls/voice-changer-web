from flask import Flask, request, send_file
import requests
from io import BytesIO
import os

app = Flask(__name__)
ELEVEN_API_KEY = os.getenv("ELEVENLABS_API_KEY")
VOICE_ID = "EXAVITQu4vr4xnSDxMaL"  # Default voice (Rachel)

@app.route("/generate", methods=["POST"])
def generate():
    text = request.json.get("text", "")
    headers = {
        "xi-api-key": ELEVEN_API_KEY,
        "Content-Type": "application/json"
    }
    body = {
        "text": text,
        "voice_settings": { "stability": 0.4, "similarity_boost": 0.75 }
    }
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}"
    response = requests.post(url, json=body, headers=headers)
    return send_file(BytesIO(response.content), download_name="output.mp3", mimetype="audio/mpeg")